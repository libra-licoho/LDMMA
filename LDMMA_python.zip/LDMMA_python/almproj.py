import numpy as np
def almproj(varL,group_ind,M):
    #varL_ = varL
    varL_ = {"x":varL["x"],"r":varL["r"],"rho1":varL["rho1"],"w":varL["w"],"lbd":varL["lbd"]}
    for i in range(M):
        if np.linalg.norm(varL["x"][group_ind[i]:group_ind[i+1]])**2>np.square(varL["r"][i]):
            y = varL["x"][group_ind[i]:group_ind[i+1]]
            coff = (varL["r"][i]+np.linalg.norm(y))/(2*np.linalg.norm(y))
            varL_["x"][group_ind[i]:group_ind[i+1]] = coff*y
            varL_["r"][i] = coff*np.linalg.norm(y)
        elif np.linalg.norm(varL["x"][group_ind[i]:group_ind[i+1]])<= - varL["r"][i]:
            varL_["x"][group_ind[i]:group_ind[i+1]] = 0*varL["x"][group_ind[i]:group_ind[i+1]]
            varL_["r"][i] = 0
        if np.linalg.norm(varL["rho1"][group_ind[i]:group_ind[i+1]])**2>np.square(varL["lbd"][i]):
            y = varL["rho1"][group_ind[i]:group_ind[i+1]]
            coff = (varL["lbd"][i]+np.linalg.norm(y))/(2*np.linalg.norm(y))
            varL_["rho1"][group_ind[i]:group_ind[i+1]] = coff*y
            varL_["lbd"][i] = coff*np.linalg.norm(y)
        elif np.linalg.norm(varL["rho1"][group_ind[i]:group_ind[i+1]])<= - varL["lbd"][i]:
            varL_["rho1"][group_ind[i]:group_ind[i+1]] = 0*varL["rho1"][group_ind[i]:group_ind[i+1]]
            varL_["lbd"][i] = 0
    return varL_


def almproj_elastic(varL,projtol):
    varL_ = {"x":varL["x"],"r":varL["r"],"rho1":varL["rho1"],"rho2":varL["rho2"],"w":varL["w"],"s":varL["s"],"lbd":varL["lbd"]}
    x = varL["x"]
    r = varL["r"]
    rho1 = varL["rho1"]
    lbd = varL["lbd"]
    if np.linalg.norm(x[0])**2>np.square(r[0]):
        paralam = 0
        objval = np.sum(np.maximum(0,abs(x)-paralam))-1
        while(abs(objval)>projtol):
            objval = np.sum(np.maximum(0,abs(x)-paralam))-1
            df = np.sum(-((abs(x)-paralam)>0))
            paralam = paralam - (objval/df)
        
        paralam = np.maximum(paralam,0)
        varL_["x"] = np.multiply(np.sign(x),np.maximum(abs(x)-paralam,0))
        varL_["r"][0] = r[0]+paralam
        #x_new = np.multiply(np.sign(x),np.maximum(abs(x)-paralam,0))
        #r_new = r[0]+paralam
        #varL_["x"] = x_new
        
    if np.linalg.norm(rho1,np.inf)**2>np.square(lbd[0]):
        paramu = 0
        objval = np.sum(np.maximum(0,abs(rho1)-paramu))-1
        while(abs(objval)>projtol):
            objval = np.sum(np.maximum(0,abs(rho1)-paramu))-1
            df = np.sum(-((abs(rho1)-paralam)>0))
            paramu = paramu - (objval/df)
            
        paramu = np.maximum(paramu,0)
        varL_["rho1"] = rho1 - np.multiply(np.sign(rho1),np.maximum(abs(rho1)-paralam,0))
        varL_["lbd"][0] = lbd[0]+paramu
    return varL_
            
        
        

        