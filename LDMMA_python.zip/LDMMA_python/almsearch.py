#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 8 14:52:53 2022

@author: severe
"""

import numpy as np
from almproj import *

def gd_elastic(varL0,grad,varL_old,grad_old,mod,L,mu,delta1,delta2,tau1,tau2,projtol):
    varL = {"x":varL0["x"],"r":varL0["r"],"rho1":varL0["rho1"],"rho2":varL0["rho2"],"w":varL0["w"],"lbd":varL0["lbd"],"s":varL0["s"]}
    s = {"x":varL0["x"]-varL_old["x"],"r":varL0["r"]-varL_old["r"],"rho1":varL0["rho1"]-varL_old["rho1"],"rho2":varL0["rho2"]-varL_old["rho2"],"w":varL0["w"]-varL_old["w"],"lbd":varL0["lbd"]-varL_old["lbd"],"s":varL0["s"]-varL_old["s"]}
    y = {"x":grad["x"]-grad_old["x"],"r":grad["r"]-grad_old["r"],"rho1":grad["rho1"]-grad_old["rho"],"rho2":grad["rho2"]-grad_old["rho2"],"w":grad["w"]-grad_old["w"],"lbd":grad["lbd"]-grad_old["lbd"],"s":grad["s"]-grad_old["s"]}
    if mod == 1:
        alpha = (s["x"].T@y["x"]+s["r"].T@y["r"]+s["rho1"].T@y["rho1"]+s["rho2"].T@y["rho2"]+s["lbd"].T@y["lbd"]+s["w"].T@y["w"]+s["s"].T@y["s"])/(y["x"].T@y["x"]+y["r"].T@y["r"]+y["rho1"].T@y["rho1"]+y["rho2"].T@y["rho2"]+y["lbd"].T@y["lbd"]+y["w"].T@y["w"]+y["s"].T@y["s"]+1e-8)
    else:
        alpha = (s["x"].T@s["x"]+s["r"].T@s["r"]+s["rho1"].T@s["rho1"]+s["rho2"].T@s["rho2"]+s["lbd"].T@s["lbd"]+s["w"].T@s["w"]+s["s"].T@s["s"])/(s["x"].T@y["x"]+s["r"].T@y["r"]+s["rho1"].T@y["rho1"]+s["rho2"].T@y["rho2"]+s["lbd"].T@y["lbd"]+s["w"].T@y["w"]+s["s"].T@y["s"]+1e-8)
    
    alpha = np.minimum(alpha,1e-2)
    alpha = np.maximum(alpha,1e-6)
    varL["x"] = varL0["x"] - alpha*grad["x"]
    varL["r"] = varL0["r"] - alpha*grad["r"]
    varL["rho1"] = varL0["rho1"] - alpha*grad["rho1"]
    varL["rho2"] = varL0["rho2"] - alpha*grad["rho2"]
    varL["lbd"] = varL0["lbd"] - alpha*grad["lbd"]
    varL["w"] = varL0["w"] - alpha*grad["w"]
    varL["s"] = varL0["s"] - alpha*grad["s"]
    varL = almproj_elastic(varL, projtol)
    grad0_norm2 = np.linalg.norm(grad["x"])**2+np.linalg.norm(grad["r"])**2+np.linalg.norm(grad["rho1"])**2+np.linalg.norm(grad["rho2"])**2+np.linalg.norm(grad["lbd"])**2+np.linalg.norm(grad["s"])**2+np.linalg.norm(grad["w"])**2
    its = 1
    while L(varL,mu,delta1,delta2,tau1,tau2)>=L(varL0,mu,delta1,delta2,tau1,tau2)-1e-3*alpha*grad0_norm2 and its<6:
        its = its+1
        alpha = 0.1*alpha
        varL["x"] = varL0["x"] - alpha*grad["x"]
        varL["r"] = varL0["r"] - alpha*grad["r"]
        varL["rho1"] = varL0["rho1"] - alpha*grad["rho1"]
        varL["rho2"] = varL0["rho2"] - alpha*grad["rho"]
        varL["lbd"] = varL0["lbd"] - alpha*grad["lbd"]
        varL["w"] = varL0["w"] - alpha*grad["w"]
        varL["s"] = varL0["s"] - alpha*grad["s"]
        varL = almproj_elastic(varL,projtol)
    return varL

'''       
def gd(varL0,grad,varL_old,grad_old,mod,L,mu,delta1,delta2,group_ind,M):
    varL = {"x":varL0["x"],"r":varL0["r"],"rho1":varL0["rho1"],"w":varL0["w"],"lbd":varL0["lbd"]}
    s = {"x":varL0["x"]-varL_old["x"],"r":varL0["r"]-varL_old["r"],"rho1":varL0["rho1"]-varL_old["rho1"],"w":varL0["w"]-varL_old["w"],"lbd":varL0["lbd"]-varL_old["lbd"]}
    y = {"x":grad["x"]-grad_old["x"],"r":grad["r"]-grad_old["r"],"rho1":grad["rho1"]-grad_old["rho1"],"w":grad["w"]-grad_old["w"],"lbd":grad["lbd"]-grad_old["lbd"]}
    if mod==1:
        alpha = (s["x"].T@y["x"]+s["r"].T@y["r"]+s["rho1"].T@y["rho1"]+s["lbd"].T@y["lbd"]+s["w"].T@y["w"])/(y["x"].T@y["x"]+y["r"].T@y["r"]+y["rho1"].T@y["rho1"]+y["lbd"].T@y["lbd"]+y["w"].T@y["w"]+1e-8)
    else:
        alpha = (s["x"].T@s["x"]+s["r"].T@s["r"]+s["rho1"].T@s["rho1"]+s["lbd"].T@s["lbd"]+s["w"].T@s["w"])/(s["x"].T@y["x"]+s["r"].T@y["r"]+s["rho1"].T@y["rho1"]+s["lbd"].T@y["lbd"]+s["w"].T@y["w"]+1e-8)
    alpha = np.minimum(alpha,1e-2)
    alpha = np.maximum(alpha,1e-6)
    varL["x"] = varL0["x"] - alpha*grad["x"]
    varL["r"] = varL0["r"] - alpha*grad["r"]
    varL["rho1"] = varL0["rho1"] - alpha*grad["rho1"]
    varL["lbd"] = varL0["lbd"] - alpha*grad["lbd"]
    varL["w"] = varL0["w"] - alpha*grad["w"]
    varL = almproj(varL,group_ind,M)
    grad0_norm2 = np.linalg.norm(grad["x"])**2+np.linalg.norm(grad["r"])**2+np.linalg.norm(grad["rho1"])**2+np.linalg.norm(grad["lbd"])**2+np.linalg.norm(grad["w"])**2
    its = 1
    while L(varL,mu,delta1,delta2)>=L(varL0,mu,delta1,delta2)-1e-3*alpha*grad0_norm2 and its<6:
        its = its+1
        alpha = 0.1*alpha
        varL["x"] = varL0["x"] - alpha*grad["x"]
        varL["r"] = varL0["r"] - alpha*grad["r"]
        varL["rho1"] = varL0["rho1"] - alpha*grad["rho1"]
        varL["lbd"] = varL0["lbd"] - alpha*grad["lbd"]
        varL["w"] = varL0["w"] - alpha*grad["w"]
        varL = almproj(varL,group_ind,M)
    return varL
'''

def frac12(varL0,varL):
    #varL_ = varL0
    varL_ = {"x":varL0["x"],"r":varL0["r"],"rho1":varL0["rho1"],"rho2":varL0["rho2"],"w":varL0["w"],"lbd":varL0["lbd"],"s":varL0["s"]}
    varL_["x"] = (varL0["x"] +varL["x"] )*0.5
    varL_["r"] = (varL0["r"] +varL["r"] )*0.5
    varL_["rho1"] = (varL0["rho1"] +varL["rho1"] )*0.5
    varL_["rho2"] = (varL0["rho2"] +varL["rho2"] )*0.5
    varL_["lbd"] = (varL0["lbd"] +varL["lbd"] )*0.5
    varL_["w"] = (varL0["w"] +varL["w"] )*0.5
    varL_["s"] = (varL0["s"] +varL["s"] )*0.5
    return varL_

def var_norm(varL1,varL2):
    x_ = np.linalg.norm(varL1["x"]-varL2["x"])**2
    r_ = np.linalg.norm(varL1["r"]-varL2["r"])**2
    rho1_ = np.linalg.norm(varL1["rho1"]-varL2["rho1"])**2
    rho2_ = np.linalg.norm(varL1["rho2"]-varL2["rho2"])**2
    lbd_ = np.linalg.norm(varL1["lbd"]-varL2["lbd"])**2
    w_ = np.linalg.norm(varL1["w"]-varL2["w"])**2
    s_ = np.linalg.norm(varL1["s"]-varL2["s"])**2
    return np.sqrt(x_+r_+rho1_+rho2_+w_+lbd_+s_)

def almsearch(L,dL,varL_ini,mu,delta1,delta2,omega,Xtol,alpha,miter,varL_old):
    MAXITS = miter
    GOLD = (1+np.sqrt(5))/2
    ALPHA = alpha
    TOL = max([Xtol, omega])
    
    varL0 = {"x":varL_ini["x"],"r":varL_ini["r"],"rho1":varL_ini["rho1"],"rho2":varL_ini["rho2"],"w":varL_ini["w"],"lbd":varL_ini["lbd"],"s":varL_ini["s"]}
    grad = dL(varL0,mu,delta1,delta2,tau1,tau2)
    varL = frac12(varL0,varL0)
    its = 1
    
    varL_p = {"x":varL["x"],"r":varL["r"],"rho1":varL["rho1"],"rho2":varL["rho2"],"w":varL["w"],"lbd":varL["lbd"],"s":varL["s"]}
    grad_old = dL(varL_old,mu,delta1,delta2,tau1,tau2)
    while its<200:
        ALPHA1 = 1e-1
        mod = np.mod(its,2)
        grad = dL(varL,mu,delta1,delta2)
        #gd_elastic(varL0,grad,varL_old,grad_old,mod,L,mu,delta1,delta2,tau1,tau2,projtol):
        varL = gd(varL,grad,varL_old,grad_old,mod,L,mu,delta1,delta2)
        varL_old = {"x":varL_p["x"],"r":varL_p["r"],"rho1":varL_p["rho1"],"w":varL_p["w"],"lbd":varL_p["lbd"]}
        grad_old = dL(varL_p,mu,delta1,delta2,tau1,tau2)
        varL_p = {"x":varL["x"],"r":varL["r"],"rho1":varL["rho1"],"rho2":varL["rho2"],"w":varL["w"],"lbd":varL["lbd"],"s":varL["s"]}
        its = its+1
    return varL

















